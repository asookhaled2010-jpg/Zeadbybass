
local date = os.date("%Y-%m-%d")
local info = [[
___________________________________________________
🔹◽ ALL CRASH REMOVER SUPPORT  64 ◽◽
___________________________________________________
_________________________________________________
😅 Script By @RAHMANYVI 😊
_________________________________________________
🇦🇫 TELEGRAM CHANNEL: @RAHMANYVI 🇦🇫 
_________________________________________________
Today ⌚ Is: ]] .. date .. [[
]]
gg.alert(info)



gg.setVisible(false) gg.clearResults() gg.clearList(t) 
gg.clearResults()
gg.setVisible(false)
gg.sleep(1)
gg.setVisible(false)
gg.setVisible(false)


function S_Pointer(t_So, t_Offset, _bit)
	local function getRanges()
		local ranges = {}
		local t = gg.getRangesList('^/data/*.so*$')
		for i, v in pairs(t) do
			if v.type:sub(2, 2) == 'w' then
				table.insert(ranges, v)
			end
		end
		return ranges
	end
	local function Get_Address(N_So, Offset, ti_bit)
		local ti = gg.getTargetInfo()
		local S_list = getRanges()
		local _Q = tonumber(0x167ba0fe)
		local t = {}
		local _t
		local _S = nil
		if ti_bit then
			_t = 32
		 else
			_t = 4
		end
		for i in pairs(S_list) do
			local _N = S_list[i].internalName:gsub('^.*/', '')
			if N_So[1] == _N and N_So[2] == S_list[i].state then
				_S = S_list[i]
				break
			end
		end
		if _S then
			t[#t + 1] = {}
			t[#t].address = _S.start + Offset[1]
			t[#t].flags = _t
			if #Offset ~= 1 then
				for i = 2, #Offset do
					local S = gg.getValues(t)
					t = {}
					for _ in pairs(S) do
						if not ti.x64 then
					
						end
						t[#t + 1] = {}
						t[#t].address = S[_].value + Offset[i]
						t[#t].flags = _t
					end
				end
			end
			_S = t[#t].address
		end
		return _S
	end
	local _A = string.format('0x%X', Get_Address(t_So, t_Offset, _bit))
	return _A
end



local t = {"libanogs.so:bss", "Cb"}
local tt = {0x5D8}
local ttt = S_Pointer(t, tt, true)
gg.addListItems({{address = ttt, flags = 4, value = 4096, freeze = true}})



gg.toast("Crash Fix [Done]")
gg.alert("Telegram : @RAHMANYVI")
gg.setVisible(false) gg.clearResults() gg.clearList(t) 

--@RAHMANYVI

--Channel; @RAHMANYVI